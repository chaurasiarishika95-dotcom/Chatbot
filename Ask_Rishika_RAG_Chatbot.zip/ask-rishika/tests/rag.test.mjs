// Offline tests with a fake embedder (no API key needed). Run: npm test
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createRag, buildContext, cosine, CONFIG } from '../lib/rag.js';

const chunks = JSON.parse(fs.readFileSync(new URL('../data/chunks.json', import.meta.url)));
// Fake embedding: hashed bag of words, 256 dims.
const STOP = new Set('the a an and of to in on for with is are was her she what how did does it this that by from as at be or'.split(' '));
const fakeEmbed = (t) => { const v = new Array(256).fill(0); for (const w of t.toLowerCase().match(/[a-z0-9]+/g) || []) { if (STOP.has(w)) continue; let h = 0; for (const c of w) h = (h * 31 + c.charCodeAt(0)) >>> 0; v[h % 256] += 1; } return v; };

let calls = [];
const deps = (failFirst = false) => ({
  embedDocs: async (ts) => ts.map(fakeEmbed),
  embedQuery: async (t) => fakeEmbed(t),
  generate: async (model, sys, user) => {
    calls.push(model);
    if (failFirst && model === CONFIG.models[0]) throw new Error('boom');
    return { text: 'ok answer', usage: { promptTokenCount: 500, candidatesTokenCount: 50 } };
  },
});

let pass = 0;
const test = async (name, fn) => { await fn(); pass++; console.log('PASS', name); };

await test('cosine of identical vectors is 1', () => assert.equal(+cosine([1, 2, 3], [1, 2, 3]).toFixed(6), 1));

await test('retrieves the right section', async () => {
  CONFIG.minScore = 0.1;
  const ask = createRag(chunks, deps());
  const out = await ask('benefit analysis turnaround manual hours countries');
  assert.equal(out.trace.retrieved[0].section, 'Benefit analysis');
});

await test('refuses below threshold without calling the model', async () => {
  CONFIG.minScore = 0.99; calls = [];
  const ask = createRag(chunks, deps());
  const out = await ask('favourite cricket team');
  assert.equal(out.refused, true);
  assert.equal(calls.length, 0);
  assert.equal(out.trace.tokens.input, 0);
});

await test('falls back to the second model when the first fails', async () => {
  CONFIG.minScore = 0.1; calls = [];
  const ask = createRag(chunks, deps(true));
  const out = await ask('voice bot evaluation pass rate');
  assert.deepEqual(calls, CONFIG.models.slice(0, 2));
  assert.equal(out.trace.fallbackUsed, true);
  assert.ok(out.trace.costUsd > 0);
});

await test('context stays within the token budget', () => {
  const big = chunks.map(c => ({ ...c, score: 1 }));
  const ctx = buildContext(big, 300);
  assert.ok(ctx.tokens <= 300 && ctx.used.length >= 1);
});

await test('empty question is rejected', async () => {
  const ask = createRag(chunks, deps());
  assert.ok((await ask('   ')).error);
});

console.log(`\n${pass} tests passed`);
