# About Rishika

## Summary
Rishika Chaurasia is a Business Analyst at Cognizant in Gurugram, India, working in the HR Tech team on a Global Mobility (visa and immigration) platform. She has 2+ years of experience across business analysis, product delivery and digital marketing. She works at the intersection of business teams, engineering, AI teams and QA, turning business problems into requirements and shipped features.

## Education
- PGDM (Post Graduate Diploma in Management), Operations & Marketing, Institute of Management Technology (IMT) Hyderabad, 2023–2025. GPA 9.13/10, in the top 5% of her batch.
- B.Com. (Hons.), Ramjas College, University of Delhi, 2017–2020. GPA 7.35/10, First Division.

## What she is looking for
Product roles such as Associate Product Manager and Product Analyst, and related roles in implementation, business analysis and operations analytics, especially where she can work hands-on with AI and data.

## Links
- LinkedIn: https://www.linkedin.com/in/rishika-chaurasia-81145a152/
- Portfolio: https://portfolio-rishika-82.vercel.app/
- GitHub: https://github.com/chaurasiarishika95-dotcom
Her CV is shared by email on request, not as a public download.
