# Skills and certifications

## Product
Product discovery, prioritisation, BRDs and PRDs, user stories and acceptance criteria, UX flows and wireframes, Agile delivery, UAT and release management, KPI scorecards, A/B testing.

## AI and technical
Prompt design (system prompts, guardrails, fallbacks), RAG, LLM evaluation and hallucination testing, model fallback for cost and latency, AI-assisted coding with Claude and Lovable, Gemini API, Supabase (Postgres), Vercel, GitHub, SQL, advanced Excel, Power BI, Google Analytics, Azure DevOps, Jira.

## Process
Lean Six Sigma, DMAIC, root cause analysis, process mapping, stakeholder management.

## Certifications
Microsoft Certified AI Transformation Leader; AI Fluency Framework & Foundations (Anthropic); Lean Six Sigma Green Belt (Grant Thornton); Agile Business Analysis (Udemy).
