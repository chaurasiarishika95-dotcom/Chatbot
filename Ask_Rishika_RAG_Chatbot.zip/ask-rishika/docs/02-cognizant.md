# Work at Cognizant (Business Analyst, Jul 2025 – present)

## The Global Mobility platform
Rishika works on a programme that brings 20+ legacy immigration applications into one unified HR Global Mobility platform. The goal is to make visa and immigration processes simpler for employees and for the HR and Global Mobility teams. She maps current workflows, country-specific process variations, dependencies between applications and process gaps, and looks for steps to standardise and automate.

## Requirements and backlog
She runs requirement discovery sessions with global business teams, HR stakeholders and Product Owners. She writes Business Requirements Documents (BRDs), user stories, acceptance criteria, business rules, L0/L1 process flows and UX flows. She owns a backlog of 40+ Epics and user stories in Azure DevOps, runs backlog refinement and product demos in an Agile setup, and has managed 25 change requests.

## Testing and release
She has coordinated 30+ UAT (user acceptance testing) cycles, with 150 defects closed before release. When the same kinds of defects kept coming back, she set up her own pre-UAT testing: she wrote test cases, including edge cases, and tested releases before business users saw them, so issues were caught earlier.

## Benefit analysis
She built the post-launch benefit analysis and KPI scorecard for a business-visa application that moved to the new platform, in advanced Excel (PivotTables, lookups, nested IF). It showed turnaround falling from 42.1 to 22.3 days (47%) and about 120 manual hours saved a month across 10 countries. She presented it to HR leadership and the CIO team, and it is reviewed quarterly.

## Data audit
She audited 25,000 migrated records against the legacy system and got mismatches fixed before users were affected. This is separate work from the benefit analysis.

## AI reporting feature
She coordinated delivery of a GenAI reporting assistant: an LLM-based text-to-SQL system that answers natural-language business questions from the database instead of manual Excel reports. The design uses GPT first and Claude as a fallback model to balance cost and latency. She pre-UAT tested its answers against the source data before release.

## Recognition
She received a Certificate of Appreciation from the Global Tech HR team for identifying AI use cases, and is a member of Cognizant's Responsible AI (RAI) group.
