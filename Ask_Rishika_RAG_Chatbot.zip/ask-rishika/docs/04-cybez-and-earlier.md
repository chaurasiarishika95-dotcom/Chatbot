# Earlier experience

## Cybez LLP (Senior Executive, Digital Marketing, Jul 2021 – Jul 2022)
At Cybez, a digital agency in Gurugram, Rishika managed 10+ client projects for e-commerce and D2C brands, mainly startups and small businesses such as Mulmul and Femella (women's fashion labels) and Roastery Coffee House. She was the primary point of contact for clients, coordinated content, design, SEO and development teams, and ran weekly and monthly reviews with founders and marketing heads.

## Growth work at Cybez
She tracked client funnels in Google Analytics and Power BI. She noticed that blogs drew the most views but readers had no easy way to buy, so she added direct checkout links from blog content to product pages. Sales from blog traffic rose 25% quarter on quarter. She also built product listings on Shopify and WordPress stores and added customer reviews. Her proposal decks and pre-onboarding analysis presentations for prospective clients contributed to a 20% increase in lead conversion.

## Calvin Klein (Customer Relations Officer intern, Apr – Jun 2024, Hyderabad)
She was the top sales performer among Customer Relations Officers, with ₹20 lakh in sales, by understanding customer needs and guiding them to the right products. She also handled billing, returns and store operations.

## IMI Precision Engineering (Sales & Operations intern, Jun – Aug 2019)
She analysed 6 months of order-tracker data to find issues in order processing and recommended process fixes.

## Leadership at IMT Hyderabad
TEDx IMT Hyderabad coordinator (brand strategy and event visibility) and Head of the Dhanak dance society, a 40+ member team.
