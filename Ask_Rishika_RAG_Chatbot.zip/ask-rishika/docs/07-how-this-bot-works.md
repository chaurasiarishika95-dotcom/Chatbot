# How this chatbot works

## Overview
Ask Rishika is a retrieval-augmented generation (RAG) chatbot that Rishika built with AI-assisted coding. It answers only from her own documents, which are split into small chunks.

## Embeddings and vector search
Each chunk is turned into an embedding (a list of 768 numbers) with Google's gemini-embedding-001 model. A question is embedded the same way, and the bot finds the closest chunks by cosine similarity. The top 4 chunks become the context for the answer.

## Guardrail against made-up answers
If even the best chunk is not similar enough, the bot does not call the language model at all. It says it does not have that information. This avoids confident but wrong answers and saves tokens.

## Context window, token cost and latency
Only the top chunks are sent, within a fixed budget of about 2,500 tokens of context, so prompts stay small. The answer comes from Gemini 2.5 Flash-Lite, a fast low-cost model, with Gemini 2.5 Flash as an automatic fallback. Each answer shows the chunks used, their similarity scores, the token counts reported by the API, an estimated cost and the time taken.
