# AI Visa Assistant (Cognizant)

## The problem
Employees had recurring questions about business visas that took around an hour each to resolve through support. Rishika analysed 2,000 historical support tickets and system data to find the most common questions and their root causes.

## Prototype and buy-in
She prototyped the assistant on Lovable during Cognizant's company-wide Generative AI hackathon, after hands-on sessions run by the Lovable team. She used the prototype to win business stakeholder buy-in. The hackathon was a Guinness World Records event, and she received a participation certificate.

## What was built
She owned the assistant from ideation to rollout. Working with Engineering and the AI team, the existing Q&A chatbot was extended into a RAG/NLP-based, action-oriented assistant connected to the platform, so users can upload and download documents and complete the visa process in the chat.

## Her role in the design
She defined the business use case, conversation flows, prompt instructions and guardrails: what the assistant should ask, answer and refuse. She also defined the automatic fallback from action mode to Q&A mode.

## Testing and results
She ran a feedback loop between testers and the AI team: wrong or weak answers were logged, fixed and re-tested before release. Testing covered hallucinations, wrong retrievals and guardrail failures, reaching 86% accuracy across 1,500 test cases. Applying DMAIC, visa process time came down from about 60 minutes to 15 minutes, a 75% reduction.
