# Projects built with AI-assisted coding

## AI Voice Bot (post-sales travel support)
A voice assistant for post-booking travel support that handles cancellations and refunds by voice and hands off to a human agent when needed, with a frustration score and a handoff ticket. To balance token cost, latency and reliability, it uses a fast, low-cost Gemini Flash-Lite model by default, falls back automatically to other models, and has a rule-based fallback if all fail. A number guard stops the LLM from changing fares or refund amounts. Rishika wrote the PRD with a north-star metric (safe autonomous resolution rate) and counter-metrics, built a 153-case evaluation, and A/B tested 6 fixes: pass rate rose from 84% to 95%, unneeded handoffs fell from 17 to 1, with zero access-control failures. Live: https://voicebot-delta-livid.vercel.app/ GitHub: https://github.com/chaurasiarishika95-dotcom/voicebot

## Network Watch (last-mile control tower)
A planner-in-the-loop tool for a North India parcel network. It maps hubs and routes on real roads using the TomTom API, adds live weather from Open-Meteo and hub capacity from a Supabase (Postgres) database, and flags deliveries likely to miss their promise. It compares recovery options with min-cost-flow allocation and recommends the lowest-cost plan for a manager to approve. Live: https://network-watch-inky.vercel.app/

## DuoSpark (consumer app)
A live date-planning app for couples built with Google Gemini, Google sign-in and a Postgres database on Supabase (profiles, couples and invites tables). Rishika also wrote its positioning and go-to-market plan, built around a partner-invite loop, and submitted it to the Google AI Startup Buildathon. Live: https://duosparks.vercel.app/

## Expansation
A planning prototype that combines capacity constraints, configurable scenarios and optimisation recommendations for network and assortment decisions. Live: https://expansation.vercel.app/

## District by Zomato analysis
A product analysis of the District app: user feedback, feature opportunities and city-level performance.

## Ask Rishika (this chatbot)
A retrieval-augmented generation (RAG) chatbot over Rishika's own documents. See "How this chatbot works".
